﻿namespace PersonInfo
{
    public interface IBirthable
    {
        public string Birthdate { get; set; }
    }
}