﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    public interface IBirthable
    {
       public DateTime Birthday { get; }
    }
}
