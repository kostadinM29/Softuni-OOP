﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models
{
    public interface IDriveable
    {
        string Drive(double distance);
    }
}
