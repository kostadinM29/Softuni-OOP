﻿using Vehicles.Interfaces;

namespace Vehicles.Models
{
    public interface IVehicle : IDriveable, IRefuelable
    {
        double FuelQuantity { get; }

        double FuelConsumption { get; }
    }
}