﻿namespace MilitaryElite
{
    public interface IPrivate
    {
        double Salary { get; }
    }
}