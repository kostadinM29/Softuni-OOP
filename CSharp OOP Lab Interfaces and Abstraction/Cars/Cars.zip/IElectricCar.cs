﻿namespace Cars
{
    interface IElectricCar
    {
        public int Battery { get; set; }
    }
}
