﻿namespace BorderControl
{
    public interface IRebel
    {
        public string Id { get; }
    }
}