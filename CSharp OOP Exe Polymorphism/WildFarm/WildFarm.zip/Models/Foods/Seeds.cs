﻿using System;
using System.Collections.Generic;
using System.Text;
using WildFarm.Models.Foods.Contracts;

namespace WildFarm.Models.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {

        }
    }
}
