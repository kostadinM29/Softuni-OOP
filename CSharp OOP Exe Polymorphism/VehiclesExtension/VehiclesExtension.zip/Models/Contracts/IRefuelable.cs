﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehiclesExtension
{
    public interface IRefuelable
    {
        void Refuel(double fuel);
    }
}
