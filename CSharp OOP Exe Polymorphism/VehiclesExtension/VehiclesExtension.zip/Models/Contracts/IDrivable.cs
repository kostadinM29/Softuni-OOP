﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehiclesExtension
{
    public interface IDriveable
    {
        string Drive(double distance);
    }
}
