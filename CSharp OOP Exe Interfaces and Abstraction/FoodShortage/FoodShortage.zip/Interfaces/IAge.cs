﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    public interface IAge
    {
        public int Age { get; }
    }
}
