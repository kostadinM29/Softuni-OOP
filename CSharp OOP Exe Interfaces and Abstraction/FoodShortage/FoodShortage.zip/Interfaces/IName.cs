﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    public interface IName
    {
        string Name { get; }
    }
}
