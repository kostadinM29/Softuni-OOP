﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Common
{
    public static class ExceptionMessage
    {
        public const string INV_ANIMAL_TYPE = "Invalid animal type!";
        public const string INV_FOOD_TYPE = "Invalid food type!";
    }
}
